open terminal run command

npm install @fortawesome/fontawesome-free@^6.7.2 axios@^1.8.1 vue@^3.5.13 vue-router@^4.5.0 vuex@^4.1.0 @vitejs/plugin-vue@^5.2.1 vite@^6.0.11 vite-plugin-vue-devtools@^7.7.1

npm install

npm run dev