<template>
    <div class="page about">
      <header>
        <img src="../../public/logo.PNG" alt="Logo" class="logo" />
        <h1>Malicious Website Finder</h1>
        <nav>
          <router-link to="/">Home</router-link>
          <router-link to="/about">About</router-link>
          
        </nav>
      </header>
      <main>
        <h2>About This Project</h2>
        <p>This project helps you identify malicious websites using multiple scanning techniques.</p>
      </main>
      <footer></footer>
    </div>
  </template>