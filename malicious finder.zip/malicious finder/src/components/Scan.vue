<template>
  <div class="page scan">
    <video autoplay muted loop class="background-video">
      <source src="../../public/scan_vid.mp4" type="video/mp4" />
      Your browser does not support the video tag.
    </video>

    <header>
      <img src="../../public/logo.PNG" alt="Logo" class="logo" />
      <h1>Malicious Website Finder</h1>
      <nav>
        <router-link to="/">Home</router-link>
        <router-link to="/about">About</router-link>
      </nav>
    </header>

    <main>
      <div class="scan-container">
        <h2>Scan a URL for Potential Threats</h2>
        <div class="input-container">
          <input v-model="url" type="url" class="scan-input" required />
          <label :class="{ active: url }">Enter URL to scan</label>
        </div>
        <button @click="scanUrl">Get Result</button>
        <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
      </div>
    </main>
  </div>
</template>

<script>
import axios from 'axios';
import { initiateScan } from '../router';

export default {
  data() {
    return {
      url: '',
      errorMessage: '',
    };
  },
  methods: {
    async scanUrl() {
      if (!this.url.trim()) {
        this.errorMessage = "Enter a valid URL";
        setTimeout(() => { this.errorMessage = ""; }, 5000);
        return;
      }

      try {
        const response = await axios.post('http://localhost:3030/checkurl', { url: this.url });

        initiateScan(); // Mark scan as initiated before navigation

        const encodedResults = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(response.data)))));
        this.$router.push({ name: 'results', query: { data: encodedResults } });

      } catch (error) {
        console.error("Error fetching results:", error.response ? error.response.data : error.message);
        this.errorMessage = "Failed to retrieve results. Try again later.";
      }
    }
  }
};
</script>


<style scoped>
/* Background Video Styling */
.background-video {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  z-index: -1;
}

/* Header Styling */
header {
  background-color: rgba(51, 51, 51, 0.8);
  color: white;
  padding: 1rem;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo {
  width: 60px;
  height: auto;
  margin-right: 1rem;
}

header h1 {
  margin: 0;
  font-size: 2rem;
  text-align: center;
  flex-grow: 1;
  font-weight: bold;
  background: linear-gradient(90deg, #2986f0, #12c1f7);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 2px 2px 10px rgba(62, 79, 236, 0.8);
}

nav {
  display: flex;
  gap: 1rem;
}

nav a {
  color: rgb(16, 153, 233);
  text-decoration: none;
  transition: all 0.3s ease;
}

nav a:hover {
  text-decoration: underline;
  color: #11ccec;
}

/* Main Container */
.scan-container {
  text-align: center;
  margin-top: 15%;
  background: rgba(0, 0, 0, 0.6);
  padding: 20px;
  border-radius: 10px;
  display: inline-block;
  color: white;
}

main {
  color: rgb(244, 244, 248);
  flex-grow: 1;
  padding: 2rem;
  padding-top: 100px;
  text-align: center;
  width: 100%;
  min-height: calc(100vh - 200px);
  position: relative;
  z-index: 1;
}

/* Input Field with Floating Label */
.input-container {
  position: relative;
  width: 60%;
  margin: auto;
}

.input-container input {
  width: 100%;
  padding: 12px 10px;
  font-size: 1rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  outline: none;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
  background: white;
}

.input-container input:focus {
  border-color: #2986f0;
  box-shadow: 0 0 5px rgba(41, 134, 240, 0.5);
}

.input-container label {
  position: absolute;
  top: 50%;
  left: 12px;
  transform: translateY(-50%);
  font-size: 1rem;
  color: #999;
  pointer-events: none;
  transition: all 0.3s ease;
  background: white;
  padding: 2px 8px;
  width: max-content;
  white-space: nowrap;
}

.input-container input:focus + label,
.input-container input:valid + label,
.input-container label.active {
  top: -10px;
  font-size: 0.8rem;
  color: #2986f0;
  background: white;
  padding: 2px 8px;
}

/* Error Message */
.error-message {
  color: red;
  font-size: 1rem;
  margin-top: 10px;
}

/* Button Styling */
button {
  margin-top: 10px;
  padding: 12px 24px;
  font-size: 1.2rem;
  font-weight: bold;
  color: white;
  background: rgb(0, 0, 255);
  border: 1px solid rgb(10, 178, 230);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.8s ease-in-out;
  text-transform: uppercase;
  box-shadow: 0 0 15px rgba(255, 0, 0, 0.7), 
              0 0 25px rgba(0, 255, 0, 0.7), 
              0 0 35px rgba(0, 0, 255, 0.7);
}

button:hover, button:focus {
  transform: scale(1.2);
  animation: rgbGlow 2s infinite alternate;
}

@keyframes rgbGlow {
  0% { box-shadow: 0 0 15px rgba(5, 219, 235, 0.7), 0 0 25px rgba(223, 3, 243, 0.7), 0 0 35px rgba(6, 248, 236, 0.7); }
  50% { box-shadow: 0 0 20px rgba(63, 5, 223, 0.9), 0 0 30px rgba(227, 8, 235, 0.9), 0 0 40px rgba(4, 228, 153, 0.9); }
  100% { box-shadow: 0 0 15px rgba(6, 212, 178, 0.7), 0 0 25px rgba(149, 4, 216, 0.7), 0 0 35px rgba(64, 230, 72, 0.7); }
}

/* Footer Styling */
footer {
  background-color: rgba(51, 51, 51, 0.8);
  color: white;
  padding: 1rem;
  text-align: center;
  width: 100%;
  height: 40px;
  z-index: 2;
}
</style>
