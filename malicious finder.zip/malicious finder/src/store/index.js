// src/store/index.js
import {createStore} from "vuex"
const store = createStore({
    state() {
      return {
        scanResults: null,
      };
    },
    mutations: {
      setScanResults(state, results) {
        state.scanResults = results;
      },
    },
    actions: {
      async scanUrl({ commit }, url) {
        try {
          const response = await fetch(`https://api.yourscanner.com/scan?url=${encodeURIComponent(url)}`);
          const data = await response.json();
          commit('setScanResults', data);
        } catch (error) {
          commit('setScanResults', { error: 'Failed to scan URL' });
        }
      },
    },
  });
  
  export default store;